$(function(){
   $('.slider').slick({
        autoplay: true,
        infinite: true,
        slidesToShow:3,
        slidesToScroll:1, 
        dots: true,     
        responsive: [   
                     {
                   breakpoint: 769,
                   settings: {
                     slidesToShow: 2,
                     slidesToScroll: 1
                   }
                 },
                 {
                   breakpoint: 480,
                   settings: {
                     slidesToShow: 1,
                     slidesToScroll: 1
                   }
                 }
           ]     
   });

    $(".slick-buttons a").on("click", function(e){
    e.preventDefault();

    $(".slick-buttons a").removeClass("active");
    $(this).addClass("active");

    const n = $(this).index();

    if (n == 0) {
        $(".slider").slick("slickUnfilter");
    } else if (n == 1) {
        $(".slider").slick("slickUnfilter");
        $(".slider").slick("slickFilter", $(".slider li").filter(".aaa"));
    } else if (n == 2) {
        $(".slider").slick("slickUnfilter");
        $(".slider").slick("slickFilter", $(".slider li").filter(".bbb"));
    } else {
        $(".slider").slick("slickUnfilter");
        $(".slider").slick("slickFilter", $(".slider li").filter(".ccc"));
    }
});
});