$(function () {
    $('.main').slick({
        dots: true,
        arrows: false,
        autoplay: true,
        infinite: true,
        autoplaySpeed: 2000,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $('.btn1').on('click', function () {
        $('.main').slick('slickPrev');
    });

    $('.btn2').on('click', function () {
        $('.main').slick('slickNext');
    });
});