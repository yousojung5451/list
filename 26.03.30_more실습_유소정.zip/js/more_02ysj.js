﻿document.addEventListener("DOMContentLoaded", function () {
  let count = 0;
  let step = 0;

  const items = document.querySelectorAll("#box ul li");
  const total = items.length;
  const btn = document.querySelector(".btn");
  const moreWrap = document.querySelector(".more");

  function setStep() {
    const w = window.innerWidth;

    if (w < 641) {
      step = 2;
    } else if (w < 1200) {
      step = 3;
    } else {
      step = 4;
    }
  }

  function showItems() {
    items.forEach((item, index) => {
      if (index < count) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });
  }

  function toggleButton() {
    if (!moreWrap) return;

    if (count >= total) {
      moreWrap.style.display = "none";
    } else {
      moreWrap.style.display = "block";
    }
  }

  function init() {
    setStep();
    count = step;
    showItems();
    toggleButton();
  }

  if (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      count = Math.min(count + step, total);
      showItems();
      toggleButton();
    });
  }

  window.addEventListener("resize", function () {
    init();
  });

  init();
});