﻿$(function(){
  let count = 0;
  let step;

  const items = $('#box ul li');
  const total = items.length;

  items.hide();
  function setStep() {
    const w = $(window).width();
    if (w < 641) step = 2;
    else if (w < 1200) step = 3;
    else step = 4;
  }

  function init() {
    setStep();
    count = step;

    items.hide();
    items.slice(0, count).show();
  }
 // $('.btn').on('click',function (e) { 
 $(document).on('click', '.btn', function(e) {
   e.preventDefault();
   count = Math.min(count + step, total);
   items.slice(0, count).fadeIn(); 

// 마지막이면 버튼 숨김
    if (count >= total) {
      $('.more').fadeOut();
    }
 });

 $(window).on('resize', function () {
    init();
    $('.more').show(); 
  });

  init();
});