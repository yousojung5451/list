document.addEventListener("DOMContentLoaded", initSlider);

//initSlider() 함수
function initSlider() {
const mainImage = document.querySelector("#slide");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");
const bookRollImgs = document.querySelectorAll("#roll a");

  let currentIndex = 0;
  let autoSlideInterval;

//현재 보이는 ul 가져오기
//getComputedStyle(el):해당 요소에 적용된 최종 계산된 CSS 값 전체를 가져옴
function getActiveUl() {
const uls = mainImage.querySelectorAll("ul");
 for (let el of uls) {
      if (window.getComputedStyle(el).display !== "none") {
        return el;
      }
    }
}

//슬라이드 이동
function slideTo(index) {
const ul = getActiveUl();
const imgs = ul.querySelectorAll("li");
const totalSlides = imgs.length;
if (index < 0) index = 0;
if (index >= totalSlides) index = totalSlides - 1;

const slideWidth = mainImage.clientWidth;

ul.style.transition = "transform 0.5s";
ul.style.transform = `translateX(-${slideWidth * index}px)`;
currentIndex = index;
updateIndicators();
}

//인디케이터
function updateIndicators() {
bookRollImgs.forEach((el, i) => {
      el.classList.toggle("active", i === currentIndex);
    });
}
/*
classList.toggle("active", 조건)
→ 조건이 true면 클래스 추가, false면 제거
jQuery의 toggleClass("클래스명", 조건)도 동일하게 동작
*/

//자동슬라이드
function startAutoSlide() {    //작업
autoSlideInterval = setInterval(() => {
    const ul = getActiveUl();
    const totalSlides = ul.querySelectorAll("li").length;  
    let nextIndex = currentIndex + 1;
    if (nextIndex >= totalSlides) nextIndex = 0;
    slideTo(nextIndex); 
  },3000);                        //   },3000); -->작업 콤마, 시간
}

function stopAutoSlide(){
  clearInterval(autoSlideInterval);
}


//이벤트
function setEventListeners(){
  prevBtn.addEventListener("click",(e) => {
    e.preventDefault();
    stopAutoSlide();
    slideTo(currentIndex -1);
    startAutoSlide();
  });

  nextBtn.addEventListener("click",(e) => {
    e.preventDefault();
    stopAutoSlide();
    slideTo(currentIndex +1);
    startAutoSlide();
  });


  bookRollImgs.forEach((el,index) => {
   el.addEventListener("click",(e) => {
    e.preventDefault();
    stopAutoSlide();
    slideTo(index);
    startAutoSlide();
   });
  });

  //화면 바뀌면 슬라이드 다시 맞춤

  window.addEventListener("resize",()=> {
    slideTo(currentIndex);
  });

}

//초기실행
 slideTo(0);
 startAutoSlide();
 setEventListeners();
}
