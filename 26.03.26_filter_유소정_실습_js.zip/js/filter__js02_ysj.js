        //자바스크립트//
document.addEventListener("DOMContentLoaded", function () {
  const tagged = {};

  // 이미지 태그 분류
  document.querySelectorAll("#gallery img").forEach(function (img) {
    const tags = img.dataset.tags;

    if (tags) {
      tags.split(",").forEach(function (tagName) {
        tagName = tagName.trim(); // ← 이거 중요 (공백 제거)

        if (!tagged[tagName]) {
          tagged[tagName] = [];
        }

        tagged[tagName].push(img);
      });
    }
  });

  // 전체 버튼
  document.querySelector(".first a").addEventListener("click", function (e) {
    e.preventDefault();

    document.querySelectorAll("#button li").forEach(function (li) {
      li.classList.remove("active");
    });

    this.classList.add("active");

    document.querySelectorAll("#gallery img").forEach(function (img) {
      img.style.display = "";
    });
  });

  // 카테고리 버튼
  document.querySelectorAll("#button li").forEach(function (li) {
    li.addEventListener("click", function () {
      
      // active 초기화
      document.querySelector(".first a").classList.remove("active");

      document.querySelectorAll("#button li").forEach(function (item) {
        item.classList.remove("active");
      });

      this.classList.add("active");

      const tagName = this.textContent.trim();

      // 전체 숨기기
      document.querySelectorAll("#gallery img").forEach(function (img) {
        img.style.display = "none";
      });

      // 해당 태그만 보이기
      if (tagged[tagName]) {
        tagged[tagName].forEach(function (img) {
          img.style.display = "";
        });
      }
    });
  });
});