        //자바스크립트//

document.addEventListener("DOMContentLoaded", function () {
  const cache = [];

 document.querySelectorAll("#gallery img").forEach(function(img){
    cache.push({
      element: img,
      text: (img.alt + " " + img.dataset.tags).trim().toLowerCase()
    });
  }); 

function filter(e) {
const query = e.target.value.trim().toLowerCase();
   let count = 0;

    cache.forEach(function(item){
     const match = item.text.indexOf(query) > -1;

      if (query === "") {
        item.element.style.display = "";
      } else {
        if (match && count < 6) {
          item.element.style.display = "";
          count++;
        } else {
          item.element.style.display = "none";
        }
      }
    });
  }

  document.getElementById("filter-search").addEventListener("input", filter);
});
